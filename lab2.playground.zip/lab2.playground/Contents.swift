import UIKit

protocol ProfileUpdateDelegate: AnyObject {
    func profileDidUpdate(_ profile: UserProfile)
    func profileLoadingError(_ error: Error)
}

protocol ImageLoaderDelegate: AnyObject {
    func imageLoader(_ loader: ImageLoader, didLoad image: UIImage)
    func imageLoader(_ loader: ImageLoader, didFailWith error: Error)
}



class ProfileManager {
    private var activeProfiles: [String: UserProfile] = [:]
    weak var delegate: ProfileUpdateDelegate?
    
    var onProfileUpdate: ((UserProfile) -> Void)?
    
    init(delegate: ProfileUpdateDelegate) {
        self.delegate = delegate
    }
    
    func loadProfile(id: String, completion: @escaping (Result<UserProfile, Error>) -> Void) {
        
        DispatchQueue.global().async { [weak self] in
            guard let self = self else { return }
            if let profile = self.activeProfiles[id] {
                completion(.success(profile))
            } else {
                completion(.failure(NSError(domain: "ProfileError", code: 404, userInfo: nil)))
            }
        }
    }
}


class UserProfileViewController {
    var profileManager: ProfileManager?
    var imageLoader: ImageLoader?
    
    func setupProfileManager() {
        profileManager = ProfileManager(delegate: self)
        profileManager?.onProfileUpdate = { [weak self] profile in
            self?.updateProfileUI(with: profile)
        }
    }
    
    func updateProfileUI(with profile: UserProfile) {
        // Update UI with new profile data
    }
}

extension UserProfileViewController: ProfileUpdateDelegate {
    func profileDidUpdate(_ profile: UserProfile) {
        updateProfileUI(with: profile)
    }
    
    func profileLoadingError(_ error: Error) {
        print("Error loading profile: \(error.localizedDescription)")
    }
}


class ImageLoader {
    weak var delegate: ImageLoaderDelegate?
    
    var completionHandler: ((UIImage?) -> Void)?
    
    func loadImage(url: URL) {
        DispatchQueue.global().async { [weak self] in
            let image = UIImage(contentsOfFile: url.path)
            DispatchQueue.main.async {
                if let image = image {
                    self?.delegate?.imageLoader(self!, didLoad: image)
                } else {
                    self?.delegate?.imageLoader(self!, didFailWith: NSError(domain: "ImageError", code: 404, userInfo: nil))
                }
            }
        }
    }
}


class PostView {
    var imageLoader: ImageLoader?
    
    func setupImageLoader() {
        imageLoader = ImageLoader()
        imageLoader?.delegate = self
    }
}

extension PostView: ImageLoaderDelegate {
    func imageLoader(_ loader: ImageLoader, didLoad image: UIImage) {
        
    }
    
    func imageLoader(_ loader: ImageLoader, didFailWith error: Error) {
        print("Image loading failed: \(error.localizedDescription)")
    }
}



class FeedSystem {
    private var userCache: [UUID: UserProfile] = [:]
    private var feedPosts: [Post] = []
    private var hashtags: Set<String> = []
    
    func addPost(_ post: Post) {
        feedPosts.insert(post, at: 0)
    }
    
    func removePost(_ post: Post) {
        feedPosts.removeAll { $0.id == post.id }
    }
}



struct UserProfile: Hashable {
    let id: UUID
    let username: String
    var bio: String
    var followers: Int
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
    
    static func == (lhs: UserProfile, rhs: UserProfile) -> Bool {
        return lhs.id == rhs.id
    }
}

struct Post: Hashable {
    let id: UUID
    let authorId: UUID
    var content: String
    var likes: Int
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
    
    static func == (lhs: Post, rhs: Post) -> Bool {
        return lhs.id == rhs.id
    }
}
